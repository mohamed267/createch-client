import React ,{useState} from 'react'

// import BannerIcon from '../../assets/icons/banner';
import IndexLayout from '../layouts'
import Banner from '../components/banner/banner'
import Projects from '../components/projects'
import Service from '../components/service'
import NewsLetter from '../components/newsLetter'
import { Box , useTheme  } from '@chakra-ui/react'
import Button from '../components/button/button'
import Head  from "next/head"

import { FaPhone, FaHandshake } from 'react-icons/fa';

import PhoneIcon from '../assets/icons/phone';
import PartnerIcon from '../assets/icons/partner';
import ContactLetter from '../components/contactLetter/contactLetter'
const Home = () => {
  const [toPartner , setToPartner] = useState<boolean>(false)
  const theme = useTheme ()
  return (
    <>
    <Head>
      <title>
        home
      </title>
    </Head>
    <div className="client">
      <Banner />
      <Projects />
      <Service />
      <NewsLetter/>
        <Box
        zIndex={"300"}
        position={"fixed"}
        bottom={"22vh"}
        px={{base : 4}}
        >
        <Button  onClick={()=>setToPartner(true)} color={"gray.600"} bg={"white"} Icon={FaHandshake} label="Be a partner" />
        <Button color={"gray.600"} Icon={FaPhone}  label="Contact us" />
      </Box>  
      
        {
          toPartner ? 
          <ContactLetter />
        : null
        }
     
    </div>
    </>
  )
}

Home.PageLayout = IndexLayout

Home.propTypes = {}

export default Home