import React  from 'react'

import {
  Flex ,
  Box,
  Stack  , 
  Heading , 
  Input , 
  Button,
  useColorModeValue,
  Text,
  FormControl,
  VStack,
  InputGroup,
  FormLabel,
  InputLeftElement,
  Textarea
} from '@chakra-ui/react'
import {  BsPerson } from 'react-icons/bs';
import { MdOutlineEmail } from 'react-icons/md';

const ContactLetter = () => {
  return (
    <Flex
    mx={"auto"}
    w={"100vw"}
    h={"100wh"}
    align={'center'}
    justify={'center'}
    my={6}
    mb={9}
    position={"fixed"}
    zIndex={500}
    top={0}
    >
    <Stack
      boxShadow={'2xl'}
      h={"100%"}
      w={{base : "auto" , md : "700px" }}
      bg={useColorModeValue('gray.blur.100', 'gray.blur.100')}
      backdropFilter={"blur(70px)"}
      rounded={'xl'}
      py={10}
      
      px={{base : 5 , md : 20}}
      spacing={8}
      align={'center'}>
      
      <Stack align={'center'} spacing={2}
        
        borderRadius={"xl"}
      >
        <Heading
          textTransform={'uppercase'}
          fontSize={'2xl'}
          color={useColorModeValue('white', 'white')}>
          You have a Business Idea to launch , Don’t worry you are at the perfect place !
        </Heading>
        <Text
            color={useColorModeValue('gray.50', 'gray.50')}
            fontSize={"md"}

        >
            Please Fill these infos and we will contact you as soon as possible 
        </Text>
      </Stack>
      <Box
                w={"100%"}
                color={useColorModeValue('gray.100', 'whiteAlpha.900')}
                >
                <VStack spacing={5}>
                  <FormControl isRequired>

                    <InputGroup>
                      <Input   
                      color={useColorModeValue('gray.100', 'whiteAlpha.900')} 
                      variant='flushed' type="text" name="name" placeholder="Your Full name" 
                      _placeholder={{ color: useColorModeValue('gray.100', 'whiteAlpha.900') }}
                      
                      />
                    </InputGroup>
                  </FormControl>

                  <FormControl isRequired>

                    <InputGroup>
                      <Input
                       variant='flushed'
                        type="email"
                        name="email"
                        placeholder="Your Email"
                        _placeholder={{ color: useColorModeValue('gray.100', 'whiteAlpha.900') }}
                      />
                    </InputGroup>
                  </FormControl>
                  <FormControl isRequired>

                    <InputGroup>
                      <Input
                      variant='flushed'
                        type="phone"
                        name="phone"
                        placeholder="Your Phone Number"
                        _placeholder={{ color: useColorModeValue('gray.100', 'whiteAlpha.900') }}
                      />
                    </InputGroup>
                  </FormControl>

                  <FormControl isRequired>

                    <Textarea
                    variant='flushed'
                      name="message"
                      placeholder="Describe your service"
                      rows={6}
                      resize="none"
                      _placeholder={{ color: useColorModeValue('gray.100', 'whiteAlpha.900') }}
                    />
                  </FormControl>

                  <Button
                  w={"100%"}
                    colorScheme="secondary.500"
                    bg="secondary.600"
                    color="white"
                    _hover={{
                      bg: 'secondary.500',
                    }}
                    
          
                    >
                    Send Message
                  </Button>
                </VStack>
              </Box>
    </Stack>
  </Flex>
  )
}

ContactLetter.propTypes = {}

export default ContactLetter